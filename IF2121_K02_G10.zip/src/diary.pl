writeDiary(Day):-
    Day =:= 1,
    write('tuliskan diary tentang Day 1: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day1'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 2,
    write('tuliskan diary tentang Day 2: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day2'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 3,
    write('tuliskan diary tentang Day 3: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day3'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 4,
    write('tuliskan diary tentang Day 4: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day4'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 5,
    write('tuliskan diary tentang Day 5: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day5'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 6,
    write('tuliskan diary tentang Day 6: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day6'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 7,
    write('tuliskan diary tentang Day 7: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day7'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 8,
    write('tuliskan diary tentang Day 8: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day8'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 9, 
    write('tuliskan diary tentang Day 9: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day9'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 10,
    write('tuliskan diary tentang Day 10: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day10'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 11,
    write('tuliskan diary tentang Day 11: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day11'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 12,
    write('tuliskan diary tentang Day 12: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day12'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 13,
    write('tuliskan diary tentang Day 13: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day13'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 14,
    write('tuliskan diary tentang Day 14: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day14'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 15,
    write('tuliskan diary tentang Day 15: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day15'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 16,
    write('tuliskan diary tentang Day 16: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day16'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 17,
    write('tuliskan diary tentang Day 17: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day17'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 18,
    write('tuliskan diary tentang Day 18: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day18'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 19,
    write('tuliskan diary tentang Day 19: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day19'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 20,
    write('tuliskan diary tentang Day 20: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day20'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 21,
    write('tuliskan diary tentang Day 21: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day21'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 22,
    write('tuliskan diary tentang Day 22: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day22'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 23,
    write('tuliskan diary tentang Day 23: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day23'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 24,
    write('tuliskan diary tentang Day 24: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day24'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 25,
    write('tuliskan diary tentang Day 25: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day25'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 26,
    write('tuliskan diary tentang Day 26: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day26'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 27,
    write('tuliskan diary tentang Day 27: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day27'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 28,
    write('tuliskan diary tentang Day 28: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day28'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 29,
    write('tuliskan diary tentang Day 29: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day29'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 30,
    write('tuliskan diary tentang Day 30: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day30'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 31,
    write('tuliskan diary tentang Day 31: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day31'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 32,
    write('tuliskan diary tentang Day 32: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day32'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 33,
    write('tuliskan diary tentang Day 33: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day33'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 34,
    write('tuliskan diary tentang Day 34: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day34'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 35,
    write('tuliskan diary tentang Day 35: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day35'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 36,
    write('tuliskan diary tentang Day 36: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day36'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 37,
    write('tuliskan diary tentang Day 37: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day37'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 38,
    write('tuliskan diary tentang Day 38: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day38'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 39,
    write('tuliskan diary tentang Day 39: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day39'),
    write('\''),
    write(Diary),
    write('\'.'),
    told, !.

writeDiary(Day):-
    Day =:= 40,
    write('tuliskan diary tentang Day 40: '),nl,
    read(Diary),
    asserta(diary(Day)),
    tell('day40'),
    write(Diary),
    told, !.

displayDiary(-1):- 
    nl, write('Here are the list of your entries: '),nl,
    displayDiary(0),!.
displayDiary(41):- !.
displayDiary(N):- 
    \+diary(N),
    N2 is N + 1,
    displayDiary(N2),!.
displayDiary(N):-
    diary(N),
    write('-   '), write('Diary Day '), write(N), nl,
    N2 is N + 1,
    displayDiary(N2),!.

readDiary(FileName) :-
    open(FileName, read, Str),
    read_file(Str,Lines),
    close(Str),
    write(Lines), nl.

read_file(Stream,[]) :-
    at_end_of_stream(Stream).

read_file(Stream,[X|L]) :-
    \+ at_end_of_stream(Stream),
    read(Stream,X),
    read_file(Stream,L).